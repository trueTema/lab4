#include "exception.h"
#include "Sequence.h"
#include "ArraySequence.h"
#include "ListSequence.h"
#include "ISorter.h"
#include "menu.h"

using namespace mysort;


bool cmp(int a, int b) {
	if (a % 2 == b % 2)
	{
		return a >= b;
	}
	else {
		return a % 2 < b % 2;
	}
}

bool cmp22(int a, int b) {
	return a >= b;
}

int main() {
	setlocale(LC_ALL, "Russian");
	srand(time(0));
	ArraySequence<int> arr = {8, 8, 1, 4, 6, 8, 4, 3, 9, 1, 2, 3, 4, 5, 6, 7};
	/*double average = 0;
	for (size_t i = 0; i < 10000; i++) {
		arr.Append((rand() % 200000) - 100000);
	}
	for (int k = 0; k < 1000; k++) {
		for (size_t i = 0; i < 10000; i++) {
			arr[i] = (rand() % 200000) - 100000;
		}
		clock_t start = clock();
		quick_sort(&arr);
		clock_t finish = clock();
		average += (double)(finish - start) / (double)CLOCKS_PER_SEC;
	}
	cout << average / 1000;*/
	shaker_sort(&arr, cmp);
	for (int i = 0; i < arr.GetLength(); cout << arr[i++] << " ");
	//menu();
	return 0;
}