#pragma once
#include <iostream>
using namespace std;
template <class T>
class DynamicArray
{
private:
	T* items = nullptr;
	int size = 0;
	size_t used_items = 0;
public:
	//������������
	DynamicArray();
	DynamicArray(int );
	DynamicArray(int , T );
	DynamicArray(T* , int );
	DynamicArray(DynamicArray<T>*);
	DynamicArray(initializer_list<T>);

	//�������������
	~DynamicArray();

	//�������
	T& Get(int );
	int GetSize();

	//��������
	void Set(int, T);
	void Resize(int );
	void Append(T );
	void Prepend(T );
	void InsertAt(T , int );
	DynamicArray<T>* GetSubArray(int , int);
	DynamicArray<T>* Concat(DynamicArray<T>* );
	void del_item(int );
	int find(int , int , T );
	DynamicArray<T>* SplitArray(bool (T));
	bool Equals(DynamicArray<T>* );
	bool IsSubArr(DynamicArray<T>* );

	//���������
	T& operator[] (int index);
	bool operator==(DynamicArray<T>& seq);
	bool operator!=(DynamicArray<T>& seq);
};
//������������
template <class T>
DynamicArray<T>::DynamicArray() {
	items = nullptr;
}
template <class T>
DynamicArray<T>::DynamicArray(int count) {
	if (count < 0) throw SetException(SizeBelowZero);
	for (int i = 0; i < count; i++) {
		this->Append(T());
	}
}
template <class T>
DynamicArray<T>::DynamicArray(int count, T fill) {
	if (count < 0) throw SetException(SizeBelowZero);
	for (int i = 0; i < count; i++) {
		this->Append(fill);
	}
}
template <class T>
DynamicArray<T>::DynamicArray(T* items, int count) {
	if (count < 0) throw SetException(SizeBelowZero);
	for (int i = 0; i < count; i++) {
		this->Append(items[i]);
	}
}
template <class T>
DynamicArray<T>::DynamicArray(DynamicArray<T>* dynamic_array) {
	for (int i = 0; i < dynamic_array->used_items; i++) {
		this->Append(dynamic_array[i]);
	}
}

template<class T>
DynamicArray<T>::DynamicArray(initializer_list<T> list) :DynamicArray(int(list.size())) {
	int j = 0;
	for (auto i : list) {
		this->items[j] = i;
		j++;
	}
}

//�������������
template <class T>
DynamicArray<T>::~DynamicArray() {
	delete[] this->items;
}


//�������
template <class T>
T& DynamicArray<T>::Get(int index) {
	if (index >= used_items || index < 0) {
		throw SetException(IndexOutOfRange);
	}
	return items[index];
}


//��������


template <class T>
void DynamicArray<T>::Resize(int NewSize) {
	if (NewSize < 0) {
		throw SetException(SizeBelowZero);
	}
	try {
		T* items_cur = new T[NewSize];
		int cpy_num = (NewSize > size ? size : NewSize);
		memcpy(items_cur, items, cpy_num * sizeof(T));
		delete[] items;
		items = items_cur;
		size = NewSize;
	}
	catch (std::bad_alloc) {
		throw SetException(MemoryAllocateError);
	}
}

template <class T>
void DynamicArray<T>::Append(T item) {
	if (used_items >= size) {
		this->Resize((size + 1) * 2);
	}
	this->Set(used_items, item);
	used_items++;
}

template <class T>
void DynamicArray<T>::Prepend(T item) {
	if (used_items >= size) {
		this->Resize((size + 1) * 2);
	}
	memmove(this->items + 1, this->items, (used_items) * sizeof(T));
	this->Set(0, item);
	used_items++;
}

template <class T>
void DynamicArray<T>::InsertAt(T item, int index) {
	if (index >= this->used_items || index < 0) {
		throw SetException(IndexOutOfRange);
	}
	if (used_items >= size) {
		this->Resize((size + 1) * 2);
	}
	
	memmove(this->items + (index + 1), this->items + (index), (used_items - 1 - index) * sizeof(T));
	this->Set(index, item);
	used_items++;
}

template <class T>
DynamicArray<T>* DynamicArray<T>::GetSubArray(int startIndex, int endIndex) {
	if (startIndex >= this->used_items || startIndex < 0 || endIndex >= this->used_items || endIndex < 0) {
		throw SetException(IndexOutOfRange);
	}
	if (endIndex < startIndex) {
		throw SetException(NegativeRange);
	}
	DynamicArray<T>* res = new DynamicArray<T>;
	for (int i = startIndex; i <= endIndex; i++) {
		res->Append(this->Get(i));
	}
	return res;
}

template <class T>
DynamicArray<T>* DynamicArray<T>::Concat(DynamicArray<T>* arr) {
	DynamicArray<T>* res = new DynamicArray<T>;
	for (int i = 0; i < used_items; i++) {
		res->Append(this->Get(i));
	}
	for (int i = 0; i < arr->GetSize(); i++) {
		res->Append(arr->Get(i));
	}
	return res;
}

template <class T>
void DynamicArray<T>::del_item(int index) {
	if (index >= this->used_items || index < 0) {
		throw SetException(IndexOutOfRange);
	}
	memmove(items + ((index)), items + ((index + 1)), (used_items - 1 - index) * sizeof(T));
	used_items--;
	if (used_items <= (size / 2)) {
		this->Resize(this->size / 2);
	}
}


template <class T>
int DynamicArray<T>::find(int startIndex, int endIndex, T item) {
	if (startIndex >= this->used_items || startIndex < 0 || endIndex >= this->used_items || endIndex < 0) {
		throw SetException(IndexOutOfRange);
	}
	if (endIndex < startIndex) {
		throw SetException(NegativeRange);
	}
	for (int i = startIndex; i <= endIndex; i++) {
		//��������� ����������
		if (this->Get(i) == item) return i;
	}
	return -1;
}

template <class T>
void DynamicArray<T>::Set(int index, T value) {
	if (index > this->used_items || index < 0) {
		throw SetException(IndexOutOfRange);
	}
	items[index] = value;
}

template <class T>
DynamicArray<T>* DynamicArray<T>::SplitArray(bool cmp(T)) {
	DynamicArray<T>* res = new DynamicArray<T>;
	for (int i = 0; i < this->used_items; i++) {
		if (cmp(this->Get(i))) {
			res->Append(this->Get(i));
			this->del_item(i);
			i--;
		}
	}
	return res;
}

template <class T>
bool DynamicArray<T>::Equals(DynamicArray<T>* seq) {
	if (this->GetSize() != seq->GetSize()) return false;
	for (int i = 0; i < seq->GetSize(); i++) {
		if (this->Get(i) != seq->Get(i)) return false;
	}
	return true;
}

template <class T>
bool DynamicArray<T>::IsSubArr(DynamicArray<T>* seq) {
	int pos = 0;
	for (int i = 0; i < seq->GetSize() && pos != -1; i++) {
		pos = this->find(pos, this->GetSize() - 1, seq->Get(i));
	}
	return pos != -1;
}

//���������
template <class T>
T& DynamicArray<T>:: operator[] (int index) {
	return this -> Get(index);
}

template <class T>
bool DynamicArray<T>:: operator==(DynamicArray<T>& seq) {
	return this->Equals(&seq);
}

template <class T>
bool DynamicArray<T>::operator!=(DynamicArray<T>& seq) {
	return !this->Equals(&seq);
}

template<class T>
int DynamicArray<T>::GetSize() {
	return used_items;
}

