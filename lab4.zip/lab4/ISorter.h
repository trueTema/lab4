#pragma once
#include "Sequence.h"
namespace mysort {



	//shaker
	template<typename T>
	void shaker_sort(Sequence<T>*, bool (T, T));

	template<typename T>
	void shaker_sort(Sequence<T>*);



	//binarysort

	template<typename T>
	void binary_insertion_sort(Sequence<T>*, bool(T, T));

	template<typename T>
	void binary_insertion_sort(Sequence<T>*);



	//mergesort

	template<typename T>
	void merge_sort(Sequence<T>*, bool(T, T));

	template<typename T>
	void merge_sort(Sequence<T>*);



	//quicksort
	
	template<typename T>
	size_t partition(Sequence<T>* ,size_t, size_t, bool(T, T));

	template<typename T>
	void quick_sort(Sequence<T>*, size_t, size_t, bool(T, T));

	template<typename T>
	void quick_sort(Sequence<T>*, bool(T, T));

	template<typename T>
	void quick_sort(Sequence<T>*);



	//bitonicsort

	template<typename T>
	void bitonic_merge(Sequence<T>*, size_t, size_t, bool(T, T), bool);

	template<typename T>
	void bitonic_sort(Sequence<T>*, size_t, size_t, bool (T, T), bool);

	template<typename T>
	void bitonic_sort(Sequence<T>*, bool (T, T));

	template<typename T>
	void bitonic_sort(Sequence<T>*);


	//etc

	template<typename T>
	void swap(T&, T&);

	template<typename T>
	bool cmp(T, T);

}


//shakersort

template<typename T>
void mysort::shaker_sort(Sequence<T>* seq, bool cmp(T, T)) {
	size_t left_sorted = 0;
	size_t right_sorted = 0;
	while (left_sorted + right_sorted < seq->GetLength()) {
		bool flag = false;
		for (int i = left_sorted; i < seq->GetLength() - right_sorted - 1; i++) {
			if (!cmp(seq->Get(i), seq->Get(i + 1))) {
				swap(seq->Get(i), seq->Get(i + 1));
				flag = true;
			}
		}
		if (!flag) {
			return;
		}
		for (int i = seq -> GetLength() - right_sorted - 1; i > left_sorted; i--) {
			if (!cmp(seq->Get(i - 1), seq->Get(i))) {
				swap(seq->Get(i), seq->Get(i - 1));
			}
		}
		right_sorted++;
		left_sorted++;
	}
	for (size_t i = 0; i < seq->GetLength() - 1; i++) {
		if (!cmp(seq->Get(i), seq->Get(i + 1))) {
			throw SetException(IncorrectComparator);
		}
	}
	return;
}

template<typename T>
void mysort::shaker_sort(Sequence<T>* seq) {
	shaker_sort(seq, mysort::cmp);
}


//shakersort

template<typename T>
void mysort::binary_insertion_sort(Sequence<T>* seq, bool cmp(T, T)) {
	size_t sorted = 0;
	for (int i = 1; i < seq->GetLength(); i++) {
		int left = -1;
		int right = i;
		T key = seq->Get(i);
		int pos = 0;
		while (left < right - 1) {
			int mid = (left + right) / 2;
			bool leftcheck = cmp(seq->Get(mid), key);
			bool rightcheck = mid + 1 >= i || cmp(key, seq->Get(mid + 1));
			if (leftcheck && rightcheck) {
				pos = mid + 1;
			}
			if (leftcheck) {
				left = mid;
			}
			else if (rightcheck) {
				right = mid;
			}
			else {
				throw SetException(IncorrectComparator);
			}
		}
		for (int j = i; j > pos; j--) {
			seq->Set(j, seq->Get(j - 1));
		}
		seq->Set(pos, key);
	}
	for (size_t i = 0; i < seq->GetLength() - 1; i++) {
		if (!cmp(seq->Get(i), seq->Get(i + 1))) {
			throw SetException(IncorrectComparator);
		}
	}
	return;
}

template<typename T>
void mysort::binary_insertion_sort(Sequence<T>* seq) {
	binary_insertion_sort(seq, mysort::cmp);
}


//mergesort

template<typename T>
void mysort::merge_sort(Sequence<T>* seq, bool cmp(T, T)) {
	if (seq->GetLength() == 1) {
		return;
	}
	size_t leftsize = seq->GetLength() / 2;
	size_t rightsize = seq->GetLength() - leftsize;
	Sequence<T>* seqleft = seq->GetSubSequence(0, leftsize - 1);
	merge_sort(seqleft, cmp);
	Sequence<T>* seqright = seq->GetSubSequence(leftsize, seq->GetLength() - 1);
	merge_sort(seqright, cmp);
	size_t leftindex = 0;
	size_t rightindex = 0;
	size_t resindex = 0;
	while (leftindex < leftsize && rightindex < rightsize) {
		if (cmp(seqleft->Get(leftindex), seqright->Get(rightindex)) && (resindex == 0 || 
			cmp(seq->Get(resindex - 1), seqleft->Get(leftindex)))) {
			seq->Set(resindex, seqleft->Get(leftindex));
			leftindex++;
		}
		else {
			seq->Set(resindex, seqright->Get(rightindex));
			rightindex++;
		}
		resindex++;
	}
	while (leftindex < leftsize) {
		seq->Set(resindex, seqleft->Get(leftindex));
		leftindex++;
		resindex++;
	}
	while (rightindex < rightsize) {
		seq->Set(resindex, seqright->Get(rightindex));
		rightindex++;
		resindex++;
	}
	for (size_t i = 0; i < seq->GetLength() - 1; i++) {
		if (!cmp(seq->Get(i), seq->Get(i + 1))) {
			throw SetException(IncorrectComparator);
		}
	}
	return;
}

template<typename T>
void mysort::merge_sort(Sequence<T>* seq) {
	merge_sort(seq, mysort::cmp);
}


//quicksort

template<typename T>
size_t mysort::partition(Sequence<T>* seq, size_t low, size_t high, bool cmp(T, T)) {
	size_t mid = (low + high) / 2;
	/*if (!cmp(seq->Get(low), seq->Get(mid))) swap(seq->Get(low), seq->Get(mid));
	if (!cmp(seq->Get(low), seq->Get(high))) swap(seq->Get(low), seq->Get(high));
	if (!cmp(seq->Get(mid), seq->Get(high))) swap(seq->Get(high), seq->Get(mid));*/
	T pivot = seq->Get(mid);
	size_t i = low;
	size_t j = high;
	while (true) {
		while (i <= high && cmp(seq->Get(i), pivot) && seq -> Get(i) != pivot) i++;
		while (j >= low && cmp(pivot, seq->Get(j)) && seq->Get(j) != pivot) j--;
		if (i >= j) return j;
		swap(seq->Get(i), seq->Get(j));
		i++;
		j--;
	}
}

template<typename T>
void mysort::quick_sort(Sequence<T>* seq, size_t low, size_t high, bool cmp(T, T)) {
	if (high - low <= 1) return;
	size_t newpivot = partition(seq, low, high, cmp);
	size_t leftindex = newpivot;
	size_t rightindex = newpivot + 1;
	quick_sort(seq, low, leftindex, cmp);
	quick_sort(seq, rightindex, high, cmp);
}

template<typename T>
void mysort::quick_sort(Sequence<T>* seq, bool cmp(T, T)) {
	quick_sort(seq, 0, seq->GetLength() - 1, cmp);
}

template<typename T>
void mysort::quick_sort(Sequence<T>* seq) {
	quick_sort(seq, mysort::cmp);
}


//bitonicsort

template<typename T>
void mysort::bitonic_merge(Sequence<T>* seq, size_t left, size_t count, bool cmp(T, T), bool reversed) {
	if (count <= 1) return;
	size_t half = count / 2;
	for (size_t i = left; i < left + half; i++) {
		if ((i + half <= left + count) && !(cmp(seq->Get(i), seq->Get(i + half)) ^ reversed)) {
			swap(seq->Get(i), seq->Get(i + half));
		}
	}
	bitonic_merge(seq, left, half, cmp, reversed);
	bitonic_merge(seq, left + half, count - half, cmp, reversed);
}

template<typename T>
void mysort::bitonic_sort(Sequence<T>* seq, size_t left, size_t count, bool cmp(T, T), bool reversed) {
	if (count <= 1) return;
	size_t half = count / 2;
	bitonic_sort(seq, left, half, cmp, false);
	bitonic_sort(seq, left + half, count - half, cmp, true);
	bitonic_merge(seq, left, count, cmp, reversed);
}

template<typename T>
void mysort::bitonic_sort(Sequence<T>* seq, bool cmp(T, T)) {
	bitonic_sort(seq, 0, seq->GetLength(), cmp, false);
}

template<typename T>
void mysort::bitonic_sort(Sequence<T>* seq) {
	bitonic_sort(seq, 0, seq->GetLength(), cmp, false);
}


//etc

template<typename T>
void mysort::swap(T& first, T& second) {
	T cur = first;
	first = second;
	second = cur;
}

template<typename T>
bool mysort::cmp(T first, T second) {
	return first <= second;
}

